package Controll;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import Entity.Consts;
import Entity.Flight;
import Entity.Plane;



public class ReportControllFrm {
	
	private static ReportControllFrm report_instance;


	public static ReportControllFrm getInstace() {
		if (report_instance == null)
			report_instance = new ReportControllFrm();
		return report_instance;
	}
	
	public ArrayList<Flight> getFlightDetails(Date fromDate, Date toDate, int x ) {
		ArrayList<Flight> datesList = new ArrayList<Flight>();
		
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					CallableStatement stmt =  conn.prepareCall(Consts.SQL_COUNTECO_F)){
				stmt.setDate(1,new java.sql.Date(fromDate.getTime()));
				stmt.setDate(2,new java.sql.Date(toDate.getTime()));
				stmt.setInt(3, x);
				ResultSet rs = stmt.executeQuery();{
					while(rs.next()) {
						int i = 1 ;
						datesList.add(new Flight(rs.getString(i++), rs.getString(i++), rs.getString(i++),
								rs.getDate(i++), rs.getDate(i++), rs.getString(i++)));
					}
				}//	public Flight(String uniqueId, String airportDepID, String airportLanID, Date departureDate, Date landingDate)
			}catch(SQLException e) {
				e.printStackTrace();
			}


		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		return datesList;
		}
}


