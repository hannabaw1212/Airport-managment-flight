package Controll;


import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import Boundary.MessageBox;
import Entity.Airport;
import Entity.Consts;
import Entity.Flight;
import Entity.Plane;

public class AddFlightControllFrm {

	private static AddFlightControllFrm addFlight_instance;


	public static AddFlightControllFrm getInstace() {
		if (addFlight_instance == null)
			addFlight_instance = new AddFlightControllFrm();
		return addFlight_instance;
	}

	private AddFlightControllFrm() {

	}

	//	public FlightAttendant(String id, String firstName, String lastName, LocalDate attachStart, LocalDate attackEnd) {
	//		super(id, firstName, lastName, attachStart, attackEnd);
	//		// TODO Auto-generated constructor stub
	//	}
	//	
//	public ArrayList<FlightAttendant> getFlightAtt(){
//		ArrayList<FlightAttendant> results = new ArrayList<FlightAttendant>();
//		try {
//			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
//			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
//					PreparedStatement stmt = conn.prepareStatement(Consts.SQL_GET_FLIGHTATT);
//					ResultSet rs = stmt.executeQuery()) {
//				while (rs.next()) {
//					int i = 1;
//					results.add(new FlightAttendant(rs.getString(i++), rs.getString(i++), rs.getString(i++), rs.getDate(i++), rs.getDate(i++)));
//				}
//			} catch (SQLException e) {
//				e.printStackTrace();
//			}
//		} catch (ClassNotFoundException e) {
//			e.printStackTrace();
//		}
//		return results;
//	}


	public ArrayList<Plane> getPlane(){
		ArrayList<Plane> results = new ArrayList<Plane>();
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					PreparedStatement stmt = conn.prepareStatement(Consts.SQL_GET_PLANE);
					ResultSet rs = stmt.executeQuery()) {
				while (rs.next()) {
					int i = 1;
					results.add(new Plane(rs.getInt(i++), rs.getInt(i++)));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return results;
	}

	public ArrayList<Airport> getAirport(){
		ArrayList<Airport> results = new ArrayList<Airport>();
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					PreparedStatement stmt = conn.prepareStatement(Consts.SQL_GET_AIRPORT);
					ResultSet rs = stmt.executeQuery()) {
				while (rs.next()) {
					int i = 1;
					results.add(new Airport(rs.getString(i++), rs.getString(i++), rs.getString(i++),rs.getInt(i++)));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return results;
	}

//	public ArrayList<Pilot> getPilots(){
//		ArrayList<Pilot> results = new ArrayList<Pilot>();
//		try {
//			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
//			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
//					PreparedStatement stmt = conn.prepareStatement(Consts.SQL_GET_PILOT);
//					ResultSet rs = stmt.executeQuery()) {
//				while (rs.next()) {
//					int i = 1;
//					results.add(new Pilot(rs.getString(i++), rs.getString(i++), rs.getString(i++),
//							rs.getDate(i++), rs.getDate(i++), rs.getString(i++), 
//							rs.getString(i++), rs.getDate(i++)));
//				}
//			} catch (SQLException e) {
//				e.printStackTrace();
//			}
//		} catch (ClassNotFoundException e) {
//			e.printStackTrace();
//		}
//		return results;
//	}
//	
//	public ArrayList<FlightAttInFlight> getFlightAttInFlight(){
//		ArrayList<FlightAttInFlight> results = new ArrayList<FlightAttInFlight>();
//		try {
//			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
//			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
//					PreparedStatement stmt = conn.prepareStatement(Consts.SQL_GET_FATTINFLIGHT);
//					ResultSet rs = stmt.executeQuery()) {
//				while (rs.next()) {
//					int i = 1;
//					results.add(new FlightAttInFlight(rs.getString(i++), rs.getString(i++)));
//				}
//			} catch (SQLException e) {
//				e.printStackTrace();
//			}
//		} catch (ClassNotFoundException e) {
//			e.printStackTrace();
//		}
//		return results;
//	}

	public ArrayList<Flight> getFlights(){
		ArrayList<Flight> results = new ArrayList<Flight>();
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					PreparedStatement stmt = conn.prepareStatement(Consts.SQL_GET_FLIGHTS);
					ResultSet rs = stmt.executeQuery()) {
				while (rs.next()) {
					int i = 1;
					results.add(new Flight(rs.getString(i++), rs.getDate(i++), rs.getDate(i++), rs.getString(i++),
							rs.getInt(i++), rs.getString(i++), rs.getString(i++)));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return results;
	}
	//	public Flight(int uniqueId, Date departureDate, Date landingDate, String status, int planeTailNumber,
	//			String airportDepID, String airportLanID, String mainPilotID, String secondPilotID) {

	public boolean addFlight(String uniqueId, Date departureDate, Date landingDate, String status, 
			int planeTailNumber, String airportDepID, String airportLanID) {

		ArrayList<Flight> flights = getFlights();
		for(Flight f : flights) {
			if(f.getUniqueId().equals(uniqueId) ) {
				MessageBox.display("Error", "Flight already exists");
				return false;
				
			}

		}
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try(Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					CallableStatement stmt = conn.prepareCall(Consts.SQL_INS_FLIGHT)){
				int i = 1 ;
				stmt.setString(i++, uniqueId);//cant be null
				stmt.setDate(i++, new java.sql.Date(departureDate.getTime()));//cant be null
				stmt.setDate(i++, new java.sql.Date(departureDate.getTime()));//cant be null
				stmt.setString(i++, status);
				stmt.setInt(i++, planeTailNumber);
				stmt.setString(i++, airportDepID);
				stmt.setString(i++, airportLanID);

				stmt.executeUpdate();
				return true;
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		return false;

	}
	
//	public boolean addFLightAttToFLight(String flightAttId, String flightID) {
//		ArrayList<FlightAttInFlight> flights = getFlightAttInFlight();
//		for(FlightAttInFlight f : flights) {
//				if(flightAttId == f.getFlightAttID() && flightID == f.getFlightID()) {
//					return false;
//				}
//			}
//		try {
//			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
//			try(Connection conn = DriverManager.getConnection(Consts.CONN_STR);
//					CallableStatement stmt = conn.prepareCall(Consts.SQL_INS_FLIGHTATTFLIGHT)){
//				int i = 1 ;
//				stmt.setString(i++, flightAttId);
//				stmt.setString(i++, flightID);
//
//				stmt.executeUpdate();
//				return true;
//			}catch(SQLException e) {
//				e.printStackTrace();
//			}
//		}catch(ClassNotFoundException e) {
//			e.printStackTrace();
//		}
//		
//	
//		return false;
//	}
//	public Airport(String airportID, String country, String city, int timeZoneGMT) {
	public boolean addAirport(String airportID, String country, String city, int timeZoneGMT) {
		ArrayList<Airport> airports = getAirport();
		for(Airport f : airports) {
			if(f.getAirportID().equals(airportID) ) {
				MessageBox.display("Error", "Airport already exists");
				return false;
			}
		}
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try(Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					CallableStatement stmt = conn.prepareCall(Consts.SQL_INS_AIRPORT)){
				int i = 1 ;
				stmt.setString(i++, airportID);//cant be null
				stmt.setString(i++, country);
				stmt.setString(i++, city);
				stmt.setInt(i++, timeZoneGMT);

				stmt.executeUpdate();
				return true;
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		return false;

		
	}

	public boolean addPlane(int tailNumber, int size) {
		ArrayList<Plane> planes = getPlane();
		for(Plane f : planes) {
			if(f.getTainNumber() == tailNumber) {
				MessageBox.display("Error", "Plane already exists");
				return false;
			}
		}
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try(Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					CallableStatement stmt = conn.prepareCall(Consts.SQL_INT_PLANE)){
				int i = 1 ;
				stmt.setInt(i++, tailNumber);//cant be null
				stmt.setInt(i++, size);

				stmt.executeUpdate();
				return true;
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		return false;
	}

}


