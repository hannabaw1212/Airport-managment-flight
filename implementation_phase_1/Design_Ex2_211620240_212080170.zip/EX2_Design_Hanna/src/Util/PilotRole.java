package Util;

public enum PilotRole {
	Main, Second;
}
