package Util;

public enum Status {
	delayed, on_time, cancelled
}
