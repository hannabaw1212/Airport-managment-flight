package Util;

public enum SeatClass {
	firstClass, economyClass, bussinessClass
}
