package Boundary;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;

import Controll.ReportControllFrm;
import Entity.Flight;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;


public class FlightSceneReportController {
		
	 @FXML
	    private DatePicker fromDate;

	    @FXML
	    private Button generateBtn;

	    @FXML
	    private Button homeBtn;

	    @FXML
	    private TextField seatX;

	    @FXML
	    private DatePicker toDate;
	    
	


	    @FXML
	    void generateReportSceneMethod(ActionEvent event) {
	    	if(seatX.getText().length() == 0) {
	    		MessageBox.display("Error", "Please choose a number of seats");
	    		return;
	    	}
	    	
	    	LocalDate fromD = fromDate.getValue();
	    	LocalDate toD = toDate.getValue();
	    	if(fromD == null || toD == null) {
	    		MessageBox.display("Error", "Please choose a date");
	    		return;
	    	}
	    	
	    	ZoneId defaultZoneId = ZoneId.systemDefault();
	    	Date lnDate = Date.from(fromD.atStartOfDay(defaultZoneId).toInstant());
	    	Date dpDate = Date.from(toD.atStartOfDay(defaultZoneId).toInstant());
	    	int x = Integer.parseInt(seatX.getText());
	    	//System.out.println(ReportControllFrm.getInstace().getFlightDetails(lnDate, dpDate, x));
	    	ArrayList<Flight>arr = ReportControllFrm.getInstace().getFlightDetails(lnDate, dpDate, x);
	    	ThereportScene.flight = arr;
	    	try {
				Parent root = FXMLLoader.load(getClass().getResource("reportScene.fxml"));
				Scene scene = new Scene(root);
				TekhenMain.mainS.setScene(scene);

			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
	    }

	    @FXML
	    void goHome(ActionEvent event) {
	    	try {
				Parent root = FXMLLoader.load(getClass().getResource("Menu.fxml"));
				Scene scene = new Scene(root);
				TekhenMain.mainS.setScene(scene);

			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
	    }
	   
	   
	    
}
