package Boundary;

import java.net.URL;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.ResourceBundle;

import Controll.AddFlightControllFrm;
import Controll.ReportControllFrm;
import Entity.Airport;
import Entity.Plane;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

public class AddFlightOrAP implements Initializable{
	
	  @FXML
	    private Button addAirportBtn;

	    @FXML
	    private Button addFlightBtn;

	    @FXML
	    private Button addPlaneBtn;

	    @FXML
	    private TextField airPortID;

	    @FXML
	    private TextField cityCombo;

	    @FXML
	    private TextField countryCombo;

	    @FXML
	    private DatePicker depDate;

	    @FXML
	    private ComboBox<Airport> desAirportCombo;

	    @FXML
	    private TextField gmtCombo;

	    @FXML
	    private Button homeBtn;

	    @FXML
	    private TextField idText;

	    @FXML
	    private ComboBox<Airport> lanAirportCombo;

	    @FXML
	    private DatePicker lanDate;

	    @FXML
	    private ComboBox<Plane> planeCombo;

	    @FXML
	    private TextField planeID;

	    @FXML
	    private TextField sizeCombo;
	    
	    @FXML
	    private ComboBox<String> statusCombo;

	    @FXML
	    void addAirport(ActionEvent event) {
	    	if(airPortID.getText().length() == 0) {
	    		System.out.println("uridjkalsdak");
	    		MessageBox.display("Error", "Please enter the new airport id");
	    		return;
	    	}
	    	if(cityCombo.getText().length() == 0) {
	    		MessageBox.display("Error", "Please enter the new airport city");
	    		return;
	    	}
	    	
	    	if(countryCombo.getText().length() == 0) {
	    		MessageBox.display("Error", "Please enter the new airport country");
	    		return;
	    	}
	    	
	    	if(gmtCombo.getText().length() == 0) {
	    		MessageBox.display("Error", "Please enter the new airport GMT");
	    		return;
	    	}
	    	String airportId = airPortID.getText();
	    	String country = countryCombo.getText();
	    	String city = cityCombo.getText();
	    	int GMT = Integer.parseInt(gmtCombo.getText());
	    boolean add = 	AddFlightControllFrm.getInstace().addAirport(airportId, country, city, GMT);
	    	
	    	if(add) {
	    		MessageBox.display("Add", "Successfully added an aiport");
	    		fillAirportCombo();
	    		return;
	    		
	    	}
	    }

	    @FXML
	    void addFlight(ActionEvent event) {
	    	if(depDate.getValue() == null) {
	    		MessageBox.display("Error", "Please choose a departure date");
	    		return;
	    
	    	}
	    	
	    	if(lanDate.getValue() == null) {
	    		MessageBox.display("Error", "Please choose a landing date");
	    		return;
	    	}
	    	LocalDate l = lanDate.getValue();
	    	LocalDate d = depDate.getValue();
	    	if(statusCombo.getSelectionModel().getSelectedIndex() == -1) {
	    		MessageBox.display("Error", "Please choose a status to the flight");
	    		return;
	    	}
	    	
	    	if(desAirportCombo.getSelectionModel().getSelectedIndex() == -1) {
	    		MessageBox.display("Error", "Please choose a destenation airport to the flight");
	    		return;
	    	}
	    	
	    	if(lanAirportCombo.getSelectionModel().getSelectedIndex() == -1) {
	    		MessageBox.display("Error", "Please choose a landing airport to the flight");
	    		return;
	    	}
	    	
	    	if(idText.getText().length() == 0) {
	    		MessageBox.display("Error", "Please choose a id  to the flight");
	    		return;
	    	}//Date date = Date.from(localDate.atStartOfDay(defaultZoneId).toInstant());
	    	
	    	if(planeCombo.getSelectionModel().getSelectedIndex() == -1) {
	    		MessageBox.display("Error", "Please choose a plane  to the flight");
	    		return;
	    	}
	    	ZoneId defaultZoneId = ZoneId.systemDefault();
	    	Date lnDate = Date.from(l.atStartOfDay(defaultZoneId).toInstant());
	    	Date dpDate = Date.from(d.atStartOfDay(defaultZoneId).toInstant());
	    	String status = statusCombo.getSelectionModel().getSelectedItem();
	    	String desAirport = desAirportCombo.getSelectionModel().getSelectedItem().getAirportID();
	    	String lanAirport = lanAirportCombo.getSelectionModel().getSelectedItem().getAirportID();
	    	int plane = planeCombo.getSelectionModel().getSelectedItem().getTainNumber();
	    	String uId = idText.getText();
	    	
	    	boolean add = AddFlightControllFrm.getInstace().addFlight(uId, dpDate, lnDate, status, plane, desAirport
	    			, lanAirport);
	    	if(add) {
	    		MessageBox.display("Add", "Successfully added a new flight");
	    		return;
	    	}else {
	    		MessageBox.display("Add", "Failed to add a new flight");
	    		return;
	    	}
	    }	
//	    }addFlight(String uniqueId, Date departureDate, Date landingDate, String status, 
//				int planeTailNumber, String airportDepID, String airportLanID) {
	    
//	    public Flight(String uniqueId, Date departureDate, Date landingDate, String status, int planeTailNumber,
//				String airportDepID, String airportLanID) {
	    @FXML
	    void addPlane(ActionEvent event) {
	    	if(planeID.getText().length() == 0) {
	    		MessageBox.display("Error", "Please fill the plane id field");
	    		return;
	    	}
	    	if(sizeCombo.getText().length() == 0 ) {
	    		MessageBox.display("Error", "Please fill the plane size field");
	    		return;
	    	}
	    	int  planeId = Integer.parseInt(planeID.getText());
	    	int planeSize = Integer.parseInt(sizeCombo.getText());
	    	boolean add = 	AddFlightControllFrm.getInstace().addPlane(planeId, planeSize);
	    	if(add == true) {
	    		MessageBox.display("Added", "Successfully added plane");
	    		fillPlaneCombo();
	    		return;
	    	}else {
	    		MessageBox.display("Added", "Failed to add plane");
	    		return;
	    	}
	    }

	    @FXML
	    void goHome(ActionEvent event) {
	    	try {
				Parent root = FXMLLoader.load(getClass().getResource("Menu.fxml"));
				Scene scene = new Scene(root);
				TekhenMain.mainS.setScene(scene);

			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
	    }

		@Override
		public void initialize(URL location, ResourceBundle resources) {
			// TODO Auto-generated method stub
			fillAirportCombo();
			fillPlaneCombo();
			fillStatus();
			
			
			//System.out.println(ReportControllFrm.getInstace().count());
		}
		
		public void fillAirportCombo() {
			ObservableList<Airport> cd=FXCollections.observableArrayList();
	    	for(Airport d : AddFlightControllFrm.getInstace().getAirport()) {
	    		cd.add(d);
	    	}
	    	lanAirportCombo.setItems(cd);
	    	desAirportCombo.setItems(cd);
	    }
		
		public void fillPlaneCombo() {
			ObservableList<Plane> cd=FXCollections.observableArrayList();
	    	for(Plane d : AddFlightControllFrm.getInstace().getPlane()) {
	    		cd.add(d);
	    	}
	    	this.planeCombo.setItems(cd);
		}
		
		public void fillStatus() {
			ObservableList<String> cd=FXCollections.observableArrayList();
			cd.add("cancelled");
			cd.add("on-time");
			cd.add("delayed");
			statusCombo.setItems(cd);
		}
}
