package Boundary;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;


public class MenuController {

	@FXML
	private Button AllFlightsBtn;

	@FXML
	private Button addFlighBtn;

	@FXML
	private Button genReportBtn;

	@FXML
	void switchToAddScene(ActionEvent event) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("AddFlightWithPAndA.fxml"));
			Scene scene = new Scene(root);
			TekhenMain.mainS.setScene(scene);

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	@FXML
	void switchToRepScene(ActionEvent event) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("FlightReportScene.fxml"));
			Scene scene = new Scene(root);
			TekhenMain.mainS.setScene(scene);

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	
	 @FXML
	    void showAllFlights(ActionEvent event) {
		 MessageBox.display("Warning", "the System is not full");
		 return;
	    }
}
