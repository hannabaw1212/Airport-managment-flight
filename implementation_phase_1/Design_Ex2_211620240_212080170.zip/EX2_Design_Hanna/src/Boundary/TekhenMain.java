package Boundary;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class TekhenMain extends Application{
	public static Stage mainS=null;
	public static void main(String[] args) throws IOException {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				try {
					primaryStage.initStyle(StageStyle.DECORATED);
					Parent root = FXMLLoader.load(getClass().getResource("Menu.fxml"));
					
					Scene scene = new Scene(root);
					mainS=primaryStage;
					primaryStage.setScene(scene);
					primaryStage.setResizable(false);
					primaryStage.show();
				} catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
				}
	}
}