package Boundary;

public class AllFlightsController {

}
