package Boundary;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Entity.Flight;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class ThereportScene implements Initializable {
	
	  @FXML
	    private TableColumn<Flight, String> airportIdCln;

	    @FXML
	    private TableColumn<Flight, String> desAiportCln;

	    @FXML
	    private TableColumn<Flight, String> desDateCln;

	    @FXML
	    private Button homeBtn;

	    @FXML
	    private TableColumn<Flight, String> lanAirportCln;

	    @FXML
	    private TableColumn<Flight, String> lanDateCln;
	    
	    @FXML
	    private TableView<Flight> flightsReportTable;
	    
	    @FXML
	    private TableColumn<Flight, String> statusCln;

	    public static ArrayList<Flight>flight ;
	    
	    
	    
	    @FXML
	    void back(ActionEvent event) {
	    	
	    	try {
				Parent root = FXMLLoader.load(getClass().getResource("FlightReportScene.fxml"));
				Scene scene = new Scene(root);
				TekhenMain.mainS.setScene(scene);

			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
            }

		@Override
		public void initialize(URL location, ResourceBundle resources) {
			// TODO Auto-generated method stub
			ObservableList<Flight>data;
	    	data=FXCollections.observableArrayList();
	    	for(Flight c: flight) {
	    		System.out.println(c.getStatus());
	    		data.add(c);
		}
	    	airportIdCln.setCellValueFactory(new PropertyValueFactory<>("uniqueId"));
	    	desAiportCln.setCellValueFactory(new PropertyValueFactory<>("airportDepID"));
	    	lanAirportCln.setCellValueFactory(new PropertyValueFactory<>("airportLanID"));
	    	lanDateCln.setCellValueFactory(new PropertyValueFactory<>("landingDate"));
	    	desDateCln.setCellValueFactory(new PropertyValueFactory<>("departureDate"));
	    	statusCln.setCellValueFactory(new PropertyValueFactory<>("status"));
	    	
	    	flightsReportTable.setItems(data);
			
		}
	    
	    

}
