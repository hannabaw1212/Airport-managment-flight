package Entity;

import java.time.LocalDate;
import java.util.Date;

import Util.PilotRole;

public class Pilot extends Employee{
	private String linNumber;
	private Date linDate;
	private String role;
	
	public Pilot(String id, String firstName, String lastName, Date attachStart, Date attackEnd, String role,
			String linNumber, Date linDate) {
		super(id, firstName, lastName, attachStart, attackEnd);
		// TODO Auto-generated constructor stub
		this.role = role;
		this.linNumber = linNumber;
		this.linDate = linDate;
	}

	public String getLinNumber() {
		return linNumber;
	}

	public void setLinNumber(String linNumber) {
		this.linNumber = linNumber;
	}

	public Date getLinDate() {
		return linDate;
	}

	public void setLinDate(Date linDate) {
		this.linDate = linDate;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	
	

}
