package Entity;

import java.time.LocalDate;
import java.util.Date;

import Util.Status;

public class GroundAttandant {
	
//	public GroundAttandant(int uniqueId, Date departureDate, Date landingDate, Status status, Plane plane,
//			Airport airportDep, Airport airportLan, Pilot mainPilot, Pilot secondPilot) {
//		super(uniqueId, departureDate, landingDate, status, plane, airportDep, airportLan, mainPilot, secondPilot);
//		// TODO Auto-generated constructor stub
//	}
//	

}
