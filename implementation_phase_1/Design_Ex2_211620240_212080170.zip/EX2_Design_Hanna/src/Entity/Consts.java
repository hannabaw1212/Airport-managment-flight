package Entity;

import java.net.URLDecoder;

public final class Consts {

	private Consts() {
		throw new AssertionError();
	}

	protected static final String DB_FILEPATH = getDBPath();
	public static final String CONN_STR = "jdbc:ucanaccess://" + DB_FILEPATH + ";COLUMNORDER=DISPLAY";
	
	
	// =======================================getting the relevant tables=========================================
	
//	public static final String SQL_GET_FLIGHTATT = "SELECT * FROM FlightAttendant";
	public static final String SQL_GET_PILOT = "SELECT * FROM Pilot";
	public static final String SQL_GET_PLANE = "SELECT * FROM Airplane";
	public static final String SQL_GET_AIRPORT = "SELECT * FROM Airport";
	public static final String SQL_GET_FLIGHTS = "SELECT * FROM Flight";
//	public static final String SQL_GET_FATTINFLIGHT = "SELECT * FROM FlightAttInFlight";
	
	//insertFattToFlight
	// ================================the add and the report====================================================
	public static final String SQL_INS_FLIGHT = "{call addFlightQU(? ,? , ?, ?, ?, ?, ?)}";
//	public static final String SQL_INS_FLIGHTATTFLIGHT = "{ call insertFattToFlight(?, ?) }";
	public static final String SQL_INS_AIRPORT = "{ call insertAirport(?, ?, ?, ?) }";
	public static final String SQL_INT_PLANE = "{ call isnertPlaneQ(?, ?) }";
	public static final String SQL_COUNTECO_F = " { call getFlightBigDetails(?, ?, ?) } ";

	private static String getDBPath() {
		try {
			String path = Consts.class.getProtectionDomain().getCodeSource().getLocation().getPath();
			String decoded = URLDecoder.decode(path, "UTF-8");
			// System.out.println(decoded) - Can help to check the returned path
			if (decoded.contains(".jar")) {
				decoded = decoded.substring(0, decoded.lastIndexOf('/'));
				return decoded + "/database/Database6.accdb";
			} else {
				decoded = decoded.substring(0, decoded.lastIndexOf("bin/"));
				System.out.println(decoded);
				return decoded + "src/entity/Database6.accdb";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}




