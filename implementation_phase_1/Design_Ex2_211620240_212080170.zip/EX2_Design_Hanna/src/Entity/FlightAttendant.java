package Entity;

import java.time.LocalDate;
import java.util.Date;

public class FlightAttendant extends Employee{

	public FlightAttendant(String id, String firstName, String lastName, Date attachStart, Date attackEnd) {
		super(id, firstName, lastName, attachStart, attackEnd);
		// TODO Auto-generated constructor stub
	}

}
