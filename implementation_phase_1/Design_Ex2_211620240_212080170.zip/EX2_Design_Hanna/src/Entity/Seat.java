package Entity;

import java.util.Objects;

import Util.SeatClass;

public class Seat {
	private int linNumber ;
	private int seatNumberInLine;
	private SeatClass classOfSeat;
	public int getLinNumber() {
		return linNumber;
	}
	public void setLinNumber(int linNumber) {
		this.linNumber = linNumber;
	}
	public int getSeatNumberInLine() {
		return seatNumberInLine;
	}
	public void setSeatNumberInLine(int seatNumberInLine) {
		this.seatNumberInLine = seatNumberInLine;
	}
	public SeatClass getClassOfSeat() {
		return classOfSeat;
	}
	public void setClassOfSeat(SeatClass classOfSeat) {
		this.classOfSeat = classOfSeat;
	}
	@Override
	public int hashCode() {
		return Objects.hash(linNumber, seatNumberInLine);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Seat other = (Seat) obj;
		return linNumber == other.linNumber && seatNumberInLine == other.seatNumberInLine;
	}
	@Override
	public String toString() {
		return "Seat [linNumber=" + linNumber + ", seatNumberInLine=" + seatNumberInLine + ", classOfSeat="
				+ classOfSeat + "]";
	}
	
	
	
	
}
