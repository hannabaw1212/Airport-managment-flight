package Entity;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Objects;

import Util.Status;

public class Flight {
	private String uniqueId;
	private Date departureDate;
	private Date landingDate;
	private String status;
	private int planeTailNumber;
	private String airportDepID;
	private String airportLanID;
	private String mainPilotID;
	private String secondPilotID;
	private ArrayList<String>FattendantsIDS;
	private int economySeats;
	
	
	
	
	public Flight(String uniqueId, Date departureDate, Date landingDate, String status, int planeTailNumber,
			String airportDepID, String airportLanID) {
		super();
		this.uniqueId = uniqueId;
		this.departureDate = departureDate;
		this.landingDate = landingDate;
		this.status = status;
		this.planeTailNumber = planeTailNumber;
		this.airportDepID = airportDepID;
		this.airportLanID = airportLanID;
		FattendantsIDS = new ArrayList<>();
		
	}
	public Flight(String uniqueId, String airportDepID, String airportLanID, Date departureDate, Date landingDate,String status) {
		super();
		this.uniqueId = uniqueId;
		this.departureDate = departureDate;
		this.landingDate = landingDate;
		this.airportDepID = airportDepID;
		this.airportLanID = airportLanID;
		this.status = status;
	}
	
	public String getUniqueId() {
		return uniqueId;
	}
	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}
	public Date getDepartureDate() {
		return departureDate;
	}
	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}
	public Date getLandingDate() {
		return landingDate;
	}
	public void setLandingDate(Date landingDate) {
		this.landingDate = landingDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getPlaneTailNumber() {
		return planeTailNumber;
	}
	public void setPlaneTailNumber(int planeTailNumber) {
		this.planeTailNumber = planeTailNumber;
	}
	public String getAirportDepID() {
		return airportDepID;
	}
	public void setAirportDepID(String airportDepID) {
		this.airportDepID = airportDepID;
	}
	public String getAirportLanID() {
		return airportLanID;
	}
	public void setAirportLanID(String airportLanID) {
		this.airportLanID = airportLanID;
	}
	public String getMainPilotID() {
		return mainPilotID;
	}
	public void setMainPilotID(String mainPilotID) {
		this.mainPilotID = mainPilotID;
	}
	public String getSecondPilotID() {
		return secondPilotID;
	}
	public void setSecondPilotID(String secondPilotID) {
		this.secondPilotID = secondPilotID;
	}
	public ArrayList<String> getFattendantsIDS() {
		return FattendantsIDS;
	}
	public void setFattendantsIDS(ArrayList<String> fattendantsIDS) {
		FattendantsIDS = fattendantsIDS;
	}


	@Override
	public int hashCode() {
		return Objects.hash(uniqueId);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Flight other = (Flight) obj;
		return uniqueId == other.uniqueId;
	}


	@Override
	public String toString() {
		return "Flight [uniqueId=" + uniqueId + ", status=" + status + "]";
	}
	
	public boolean addFlightAtt(FlightAttendant fa) {
		if(fa == null || this.FattendantsIDS.contains(fa.getId()))
			return false;
		return this.FattendantsIDS.add(fa.getId());
	}
	
	
}
