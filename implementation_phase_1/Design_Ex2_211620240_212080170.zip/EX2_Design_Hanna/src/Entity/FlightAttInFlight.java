package Entity;

public class FlightAttInFlight {
	private String flightID;
	private String flightAttID;
	
	public String getFlightID() {
		return flightID;
	}
	public void setFlightID(String flightID) {
		this.flightID = flightID;
	}
	public String getFlightAttID() {
		return flightAttID;
	}
	public void setFlightAttID(String flightAttID) {
		this.flightAttID = flightAttID;
	} 
	
	public FlightAttInFlight(String flightAttID, String flightID) {
		this.flightAttID = flightAttID;
		this.flightID = flightID;
		
	}
	@Override
	public String toString() {
		return "FlightAttInFlight [flightAttendantID=" + flightAttID + ", flightId=" + flightID + "]";
	}
	
	
	
	
}
