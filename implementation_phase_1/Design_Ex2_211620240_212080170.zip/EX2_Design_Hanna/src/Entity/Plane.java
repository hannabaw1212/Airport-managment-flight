package Entity;

import java.util.ArrayList;

public class Plane {
	private int tainNumber;
	private int size;
	private ArrayList<Seat>seats;
	private ArrayList<Flight>Flights;
	
		public Plane(int tainNumber, int size) {
		super();
		this.tainNumber = tainNumber;
		this.size = size;
	
	}
	public int getTainNumber() {
		return tainNumber;
	}
	public void setTainNumber(int tainNumber) {
		this.tainNumber = tainNumber;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public ArrayList<Seat> getSeats() {
		return seats;
	}
	public void setSeats(ArrayList<Seat> seats) {
		this.seats = seats;
	}
	
	public boolean addSeat(Seat seat) {
		if(seat == null || seats.contains(seat)) {
			return false;
		}
		return this.seats.add(seat);
	}
	
	public boolean removeSeat(Seat seat) {
		if(seat == null || !seats.contains(seat)) {
			return false;
		}
		return this.seats.remove(seat);
	}
	public ArrayList<Flight> getAirports() {
		return Flights;
	}
	public void setAirports(ArrayList<Flight> Flights) {
		this.Flights = Flights;
	}
	@Override
	public String toString() {
		return "Plane [tainNumber=" + tainNumber + ", size=" + size + "]";
	}
	
		
	
	
}
