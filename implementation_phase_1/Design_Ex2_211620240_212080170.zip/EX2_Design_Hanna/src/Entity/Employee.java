package Entity;

import java.time.LocalDate;
import java.util.Date;
import java.util.Objects;

public abstract class Employee {
	private String id;
	private String firstName;
	private String lastName;
	private Date attachStart;
	private Date attackEnd;
	public Employee(String id, String firstName, String lastName, Date attachStart, Date attackEnd) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.attachStart = attachStart;
		this.attackEnd = attackEnd;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Date getAttachStart() {
		return attachStart;
	}
	public void setAttachStart(Date attachStart) {
		this.attachStart = attachStart;
	}
	public Date getAttackEnd() {
		return attackEnd;
	}
	public void setAttackEnd(Date attackEnd) {
		this.attackEnd = attackEnd;
	}
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		return Objects.equals(id, other.id);
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", attachStart="
				+ attachStart + ", attackEnd=" + attackEnd + "]";
	}
	
	
}
