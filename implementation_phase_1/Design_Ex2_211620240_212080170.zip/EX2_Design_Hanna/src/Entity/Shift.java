package Entity;

public class Shift {

}
