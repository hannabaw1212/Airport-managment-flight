package Entity;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Objects;

public class Order {
	private int orderNumber;
	private LocalDate orderDate;
	private String wayToPay;
	private ArrayList<String>flightTickets;
	
	public Order(int orderNumber, LocalDate orderDate, String wayToPay) {
		super();
		this.orderNumber = orderNumber;
		this.orderDate = orderDate;
		this.wayToPay = wayToPay;
	}

	public int getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(int orderNumber) {
		this.orderNumber = orderNumber;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	public String getWayToPay() {
		return wayToPay;
	}

	public void setWayToPay(String wayToPay) {
		this.wayToPay = wayToPay;
	}

	@Override
	public int hashCode() {
		return Objects.hash(orderNumber);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Order other = (Order) obj;
		return orderNumber == other.orderNumber;
	}

	@Override
	public String toString() {
		return "Order [orderNumber=" + orderNumber + ", orderDate=" + orderDate + ", wayToPay=" + wayToPay + "]";
	}
	
	public boolean addFlightTicket(String FTid) {
		if(FTid == null || this.flightTickets.contains(FTid))
			return false;
		return this.flightTickets.add(FTid);
	}
	
	public boolean removeFlightTicket(String FTid) {
		if(FTid == null || !this.flightTickets.contains(FTid))
			return false;
		return this.flightTickets.remove(FTid);
	}
	
}
