package Entity;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;

public class Flight {
	private String flightID;
	private String landingCity;
	private String departureCity;
	private Date departureDate;
	private int flightTime;
	private int tailNumber;
	private java.sql.Time departureDateTime;
	private boolean isCancelled;
	
	private ArrayList<String>seats ;
	
	private ArrayList<String>flightTickets;
	
	
	
	
	public Flight(String flightID, String landingCity, String departureCity, Date departureDate, int flightTime,
			int tailNumber, java.sql.Time departureTimeHour) {
		super();
		this.flightID = flightID;
		this.landingCity = landingCity;
		this.departureCity = departureCity;
		this.departureDate = departureDate;
		this.flightTime = flightTime;
		this.tailNumber = tailNumber;
		this.departureDateTime = departureTimeHour;
		this.setSeats(new ArrayList<>());
	}
	
	public Flight(String flightID) {
		this.flightID = flightID;
	}

	public String getFlightID() {
		return flightID;
	}

	public void setFlightID(String flightID) {
		this.flightID = flightID;
	}

	public String getLandingCity() {
		return landingCity;
	}

	public void setLandingCity(String landingCity) {
		this.landingCity = landingCity;
	}

	public String getDepartureCity() {
		return departureCity;
	}

	public void setDepartureCity(String departureCity) {
		this.departureCity = departureCity;
	}

	public Date getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}

	public int getFlightTime() {
		return flightTime;
	}

	public void setFlightTime(int flightTime) {
		this.flightTime = flightTime;
	}

	public int getTailNumber() {
		return tailNumber;
	}

	public void setTailNumber(int tailNumber) {
		this.tailNumber = tailNumber;
	}

	@Override
	public int hashCode() {
		return Objects.hash(flightID);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Flight other = (Flight) obj;
		return Objects.equals(flightID, other.flightID);
	}

	

	@Override
	public String toString() {
		return "Flight [flightID=" + flightID + ", landingCity=" + landingCity + ", departureCity=" + departureCity
				+ ", departureDate=" + departureDate + "]";
	}

	public ArrayList<String> getFlightTickets() {
		return flightTickets;
	}

	public void setFlightTickets(ArrayList<String> flightTickets) {
		this.flightTickets = flightTickets;
	}

	public ArrayList<String> getSeats() {
		return seats;
	}

	public void setSeats(ArrayList<String> seats) {
		this.seats = seats;
	}

	public boolean isCancelled() {
		return isCancelled;
	}

	public void setCancelled(boolean isCancelled) {
		this.isCancelled = isCancelled;
	}

	public java.sql.Time getDepartureDateTime() {
		return departureDateTime;
	}

	public void setDepartureDateTime(java.sql.Time departureDateTime) {
		this.departureDateTime = departureDateTime;
	}
	
	
	
}
