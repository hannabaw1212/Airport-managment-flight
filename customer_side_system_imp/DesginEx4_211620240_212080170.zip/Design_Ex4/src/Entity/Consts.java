package Entity;

import java.net.URLDecoder;

public class Consts {
	
	private Consts() {
		throw new AssertionError();
	}

	protected static final String DB_FILEPATH = getDBPath();
	public static final String CONN_STR = "jdbc:ucanaccess://" + DB_FILEPATH + ";COLUMNORDER=DISPLAY";
	
	public static final String SQL_GET_PLANE = "SELECT * FROM Plane";
	public static final String SQL_GET_FLIGHT = "SELECT * FROM Flight";
	public static final String SQL_GET_SEAT = "SELECT * FROM Seat";
	public static final String SQL_GET_FLIGHTTICKETS = "SELECT * FROM FlightTicket";
	public static final String SQL_GET_CUSTOMERS = "SELECT * FROM Customer";
	
	//json add flight and update
	public static final String SQL_ADD_FLIGHT = "{call addFlightQ(?, ?, ?, ?, ?, ?, ?)}";
	public static final String SQL_UPDATE_FLIGHT = "{ call updateFlightQ(?, ?, ?, ?, ?, ?, ?, ?)}";
	
	//Json add seat and update
	public static final String SQL_ADD_SEAT = "{call addSeatQ(?, ?, ?, ?, ?)}";
	public static final String SQL_UPDATE_SEAT = "{call updateSeatQU(?, ?)}";
	
	//Report
	public static final String SQL_GET_REPORT = "SELECT * FROM flightsByHours";
	 
	
	//Handle customer and his orders
	public static final String SQL_GET_CUSTOMER_BY_ID = " call getCusbyId(?,?) }";
			
	public static final String SQL_GET_CUS_F_TICKET = "{call getFlightTickByCusId(?, ?)}";
	
	public static final String SQL_UPDATE_FLIGHT_TICKET = "{call updateFlightTicket(?, ?)}";
	
	
	
	
	
	
	
	private static String getDBPath() {
		try {
			String path = Consts.class.getProtectionDomain().getCodeSource().getLocation().getPath();
			String decoded = URLDecoder.decode(path, "UTF-8");
			// System.out.println(decoded) - Can help to check the returned path
			if (decoded.contains(".jar")) {
				decoded = decoded.substring(0, decoded.lastIndexOf('/'));
				return decoded + "/database/DatabaseEX3.accdb";
			} else {
				decoded = decoded.substring(0, decoded.lastIndexOf("bin/"));
				System.out.println(decoded);
				return decoded + "src/Entity/DatabaseEX3.accdb";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
