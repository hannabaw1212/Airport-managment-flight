package Entity;

import java.util.ArrayList;
import java.util.Objects;

public class Plane {
	private int tailNumber;
	private ArrayList<String>seats;

	public Plane(int tailNumber) {
		super();
		this.tailNumber = tailNumber;
		this.seats = new ArrayList<>();
	}

	public int getTailNumber() {
		return tailNumber;
	}

	public void setTailNumber(int tailNumber) {
		this.tailNumber = tailNumber;
	}

	@Override
	public int hashCode() {
		return Objects.hash(tailNumber);
	}
	
	public boolean addSeat(String seatId) {
		if(seatId ==  null || this.seats.contains(seatId))
			return false;
		return this.seats.add(seatId);
	}
	
	public boolean removeSeat(String seatId) {
		if(seatId ==  null || !this.seats.contains(seatId))
			return false;
		return this.seats.remove(seatId);
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Plane other = (Plane) obj;
		return tailNumber == other.tailNumber;
	}

	@Override
	public String toString() {
		return "Plane [tailNumber=" + tailNumber + "]";
	}
	
	
}
