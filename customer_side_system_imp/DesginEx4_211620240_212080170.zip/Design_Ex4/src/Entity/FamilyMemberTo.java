package Entity;

import java.util.Objects;

public class FamilyMemberTo {
	
	private String passportNumber1;
	private String passportNumber2;
	
	public FamilyMemberTo(String passportNumber1, String passportNumber2) {
		super();
		this.passportNumber1 = passportNumber1;
		this.passportNumber2 = passportNumber2;
	}

	public String getPassportNumber1() {
		return passportNumber1;
	}

	public void setPassportNumber1(String passportNumber1) {
		this.passportNumber1 = passportNumber1;
	}

	public String getPassportNumber2() {
		return passportNumber2;
	}

	public void setPassportNumber2(String passportNumber2) {
		this.passportNumber2 = passportNumber2;
	}

	@Override
	public int hashCode() {
		return Objects.hash(passportNumber1, passportNumber2);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FamilyMemberTo other = (FamilyMemberTo) obj;
		return Objects.equals(passportNumber1, other.passportNumber1)
				&& Objects.equals(passportNumber2, other.passportNumber2);
	}
	
	
	
}
