package Entity;

public class Supplier {
	
	private String supplierID;
	private String firstName;
	private String lastName;
	private String faxNumber;
	private String email;
	private String phoneNumber;
	
	public Supplier(String supplierID, String firstName, String lastName, String faxNumber, 
			String email, String phoneNumber) {
		super();
		this.supplierID = supplierID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.faxNumber = faxNumber;
		this.email = email;
		this.phoneNumber = phoneNumber;
	}

	public String getSupplierID() {
		return supplierID;
	}

	public void setSupplierID(String supplierID) {
		this.supplierID = supplierID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFaxNumber() {
		return faxNumber;
	}

	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}

	@Override
	public String toString() {
		return "Supplier [firstName=" + firstName + ", lastName=" + lastName + "]";
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	
}
