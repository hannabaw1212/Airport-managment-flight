package Entity;

import java.util.Objects;

public class Seat {
	
	private String seatID;
	private String seatClass;
	private int lineNumber;
	private int seatNumberInLine;
	private int tailNumber;
	
	public Seat(String seatID, String seatClass, int lineNumber, int seatNumberInLine, int tailNumber) {
		super();
		this.seatID = seatID;
		this.seatClass = seatClass;
		this.lineNumber = lineNumber;
		this.seatNumberInLine = seatNumberInLine;
		this.tailNumber = tailNumber;
	}
	
	public Seat(String seatId) {
		this.seatID = seatId;
	}

	public String getSeatID() {
		return seatID;
	}

	public void setSeatID(String seatID) {
		this.seatID = seatID;
	}

	public String getSeatClass() {
		return seatClass;
	}

	public void setSeatClass(String seatClass) {
		this.seatClass = seatClass;
	}

	public int getLineNumber() {
		return lineNumber;
	}

	public void setLineNumber(int lineNumber) {
		this.lineNumber = lineNumber;
	}

	public int getSeatNumberInLine() {
		return seatNumberInLine;
	}

	public void setSeatNumberInLine(int seatNumberInLine) {
		this.seatNumberInLine = seatNumberInLine;
	}

	public int getTailNumber() {
		return tailNumber;
	}

	public void setTailNumber(int tailNumber) {
		this.tailNumber = tailNumber;
	}

	@Override
	public int hashCode() {
		return Objects.hash(seatID);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Seat other = (Seat) obj;
		return Objects.equals(seatID, other.seatID);
	}

	@Override
	public String toString() {
		return "Seat [lineNumber=" + lineNumber + ", seatNumberInLine=" + seatNumberInLine + ", tailNumber="
				+ tailNumber + "]";
	}
	
	
	
}
