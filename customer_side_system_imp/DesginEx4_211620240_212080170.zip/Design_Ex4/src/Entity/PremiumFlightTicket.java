package Entity;

public class PremiumFlightTicket extends FlightTicket{
	private int maxWeight;
	private int priceByMaxWeight;
	private String requests;
	
	public PremiumFlightTicket(String ticketId, String mealType, String classWanted, String passportNumber, 
			int orderNumber, String flightId, String seatId, int maxWeight, String requests) {
		
		super(ticketId, mealType, classWanted, passportNumber, orderNumber, flightId, seatId);
		
		this.maxWeight = maxWeight;
		this.priceByMaxWeight = this.price + this.maxWeight * 20;
		this.requests = requests;
		
		// TODO Auto-generated constructor stub
		
	}
	
	public PremiumFlightTicket(String ticketId, String mealType, String classWanted, String passportNumber, 
			int orderNumber, String flightId, String seatId,  Boolean canclled, int maxWeight, String requests) {
		
		super(ticketId, mealType, classWanted, passportNumber, orderNumber, flightId, seatId);
		
		this.maxWeight = maxWeight;
		this.priceByMaxWeight = this.price + this.maxWeight * 20;
		this.requests = requests;
		
		// TODO Auto-generated constructor stub
		
	}

	public int getMaxWeight() {
		return maxWeight;
	}

	public void setMaxWeight(int maxWeight) {
		this.maxWeight = maxWeight;
	}

	public int getPriceByMaxWeight() {
		return priceByMaxWeight;
	}

	public void setPriceByMaxWeight(int priceByMaxWeight) {
		this.priceByMaxWeight = priceByMaxWeight;
	}

	public String getRequests() {
		return requests;
	}

	public void setRequests(String requests) {
		this.requests = requests;
	}
	
	
	
	
}
