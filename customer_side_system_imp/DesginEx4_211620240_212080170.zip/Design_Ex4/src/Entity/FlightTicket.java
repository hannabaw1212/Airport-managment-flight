package Entity;

import java.util.Objects;

public class FlightTicket {
	protected String ticketId;
	protected int orderNumber;
	protected String mealType;
	protected String classWanted;
	protected int price;
	protected String passportNumber;
	protected String flightId;
	protected String seatId;
	protected boolean canclled;
	
	public FlightTicket(String ticketId, String mealType, String classWanted, String passportNumber, 
			int orderNumber, String flightId, String seatId) {
		super();
		this.ticketId = ticketId;
		this.orderNumber = orderNumber;
		this.mealType = mealType;
		this.classWanted = classWanted;
		this.passportNumber = passportNumber;
		this.flightId = flightId;
		this.seatId = seatId;
		
	}
//	
//	public FlightTicket(String ticketId, String mealType, String classWanted, String passportNumber, 
//			int orderNumber, String flightId, String seatId) {
//		super();
//		this.ticketId = ticketId;
//		this.orderNumber = orderNumber;
//		this.mealType = mealType;
//		this.classWanted = classWanted;
//		this.passportNumber = passportNumber;
//		this.flightId = flightId;
//		this.seatId = seatId;
//		this.canclled = canclled;
//		
//	}
	
	public FlightTicket(String ticketId, String mealType, String classWanted, int price, String passportNumber, 
			int orderNumber, String flightId, String seatId, Boolean canclled) {
		super();
		this.ticketId = ticketId;
		this.orderNumber = orderNumber;
		this.mealType = mealType;
		this.classWanted = classWanted;
		this.passportNumber = passportNumber;
		this.flightId = flightId;
		this.seatId = seatId;
		
	}
	
	
	
	public FlightTicket(String tikcetId) {
		this.ticketId = tikcetId;
	}

	public String getTicketId() {
		return ticketId;
	}

	public void setTicketId(String ticketId) {
		this.ticketId = ticketId;
	}

	public int getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(int orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getMealType() {
		return mealType;
	}

	public void setMealType(String mealType) {
		this.mealType = mealType;
	}

	public String getClassWanted() {
		return classWanted;
	}

	public void setClassWanted(String classWanted) {
		this.classWanted = classWanted;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}

	public String getFlightId() {
		return flightId;
	}

	public void setFlightId(String flightId) {
		this.flightId = flightId;
	}

	public String getSeatId() {
		return seatId;
	}

	public void setSeatId(String seatId) {
		this.seatId = seatId;
	}

	@Override
	public int hashCode() {
		return Objects.hash(ticketId);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FlightTicket other = (FlightTicket) obj;
		return Objects.equals(ticketId, other.ticketId);
	}

	@Override
	public String toString() {
		return "FlightTicket [passportNumber=" + passportNumber + ", flightId=" + flightId + ", seatId=" + seatId + "]";
	}
	
	
	public boolean getCancelled() {
		return this.canclled;
	}
	public void setCanclled(boolean x) {
		this.canclled = x;
	}
	
}
