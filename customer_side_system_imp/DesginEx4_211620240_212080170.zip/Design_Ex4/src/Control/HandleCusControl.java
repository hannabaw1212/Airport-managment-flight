package Control;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;

import Entity.Consts;
import Entity.Customer;
import Entity.Flight;
import Entity.FlightTicket;
import Entity.Seat;

public class HandleCusControl {
		public static Customer cus = null;
	
	public static HandleCusControl handle_insatnce = null;
	
	public static HandleCusControl getInstace() {
		if (handle_insatnce == null)
			handle_insatnce = new HandleCusControl();
		return handle_insatnce;
	}
	
	//public Customer(String passportNumber, String firstName, String lastName, String email, LocalDate birthdate,
	//String primaryCitizenShip) {
	public ArrayList<Customer> getCustomers(){
		ArrayList<Customer> results = new ArrayList<Customer>();
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					PreparedStatement stmt = conn.prepareStatement(Consts.SQL_GET_CUSTOMERS);
					ResultSet rs = stmt.executeQuery()) {
				while (rs.next()) {
					int i = 1;
					results.add(new Customer(rs.getString(i++), rs.getString(i++), rs.getString(i++), rs.getString(i++),
							rs.getDate(i++), rs.getString(i++)));



				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return results;
	}
	
	public Customer getCustomerById(String cusPassport) {
		Customer customer = null ;
		ArrayList<Customer> customers = getCustomers();
		
		for(int i = 0 ; i < customers.size() ; i++) {
			if(customers.get(i).getPassportNumber().equals(cusPassport)) {
				customer  = customers.get(i);
			}
		}
		
		return customer;
	}	
	
	public ArrayList<FlightTicket> getFlightTicketByCusId(Customer customer){
		ArrayList<FlightTicket> datesList = new ArrayList<FlightTicket>();
		
		ArrayList<FlightTicket> tempTic = getFlightTickets();
		ArrayList<Flight>jsonF = new ArrayList<>(importControl.getInstace().importJsonFile("json/flights.json").keySet());
		ArrayList<String> jsonFId = new ArrayList<>();
		for(int i = 0 ; i < jsonF.size() ; i++) {
			jsonFId.add(jsonF.get(i).getFlightID());
		}
		String customerId = customer.getPassportNumber();
		for(int i = 0 ; i < tempTic.size() ; i++) {
			if(tempTic.get(i).getPassportNumber().equals(customerId) && jsonFId.contains(tempTic.get(i).getFlightId())) {
				datesList.add(tempTic.get(i));
			}
		}
		
		return datesList;
		}
	

	
	public ArrayList<FlightTicket> getFlightTickets(){
		ArrayList<FlightTicket> results = new ArrayList<FlightTicket>();
			
			try {
				Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
				try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
						PreparedStatement stmt = conn.prepareStatement(Consts.SQL_GET_FLIGHTTICKETS);
						ResultSet rs = stmt.executeQuery()) {
					while (rs.next()) {
						int i = 1;
						results.add(new FlightTicket(rs.getString(i++), rs.getString(i++), rs.getString(i++), 
								rs.getInt(i++), rs.getString(i++), rs.getInt(i++),
								rs.getString(i++), rs.getString(i++),rs.getBoolean(i++)));
					
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			ArrayList<FlightTicket> can = new ArrayList<>();
			for(int i = 0 ; i < results.size() ; i++) {
				if(results.get(i).getCancelled() == true) {
					can.add(results.get(i));
				}
			}
			results.removeAll(can);
			return results;
		}
	
	public ArrayList<Flight> getFlights() {
		ArrayList<Flight> results = new ArrayList<Flight>();
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					PreparedStatement stmt = conn.prepareStatement(Consts.SQL_GET_FLIGHT);
					ResultSet rs = stmt.executeQuery()) {
				while (rs.next()) {
					int i = 1;
					results.add(new Flight(rs.getString(i++), rs.getString(i++), rs.getString(i++), rs.getDate(i++),
							rs.getInt(i++), rs.getInt(i++), rs.getTime(i++)));



				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return results;
	}
	
//	public ArrayList<Customer> getCustomers(){
//		ArrayList<Customer> results = new ArrayList<Customer>();
//		try {
//			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
//			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
//					PreparedStatement stmt = conn.prepareStatement(Consts.SQL_GET_CUSTOMERS);
//					ResultSet rs = stmt.executeQuery()) {
//				while (rs.next()) {
//					int i = 1;
//					results.add(new Customer(rs.getString(i++), rs.getString(i++), rs.getString(i++),
//							rs.getString(i++), rs.getDate(i++), rs.getString(i++)));
//
//
//				}
//			} catch (SQLException e) {
//				e.printStackTrace();
//			}
//		} catch (ClassNotFoundException e) {
//			e.printStackTrace();
//		}
//		return results;
//	}
//	public Customer(String passportNumber, String firstName, String lastName, String email, 
//	Date birthdate,
//	String primaryCitizenShip) {
	
	public ArrayList<Flight> recomndedFlight(FlightTicket ticket){
		String FlightId = ticket.getFlightId();
		Flight ticketFlight = null;
		ArrayList<Flight> flights = getFlights();
		ArrayList<Flight>recomndedF = new ArrayList<>();
		
		for(int i = 0 ; i  < flights.size() ; i++) {
			if(flights.get(i).getFlightID().equals(FlightId)) {
				ticketFlight = flights.get(i);
				break;
			}
		}
		
		flights.remove(ticketFlight);
		String landing = ticketFlight.getLandingCity();
		String departureC = ticketFlight.getDepartureCity();
		LocalDate d = convertToLocalDateViaMilisecond(ticketFlight.getDepartureDate());
	
		for(Flight f : flights) {
			if(f.getDepartureCity()== null || f.getLandingCity() == null || f.getDepartureDate() == null) {
				continue;
			}
			String landingCity = f.getLandingCity();
			String departureCity = f.getDepartureCity();
			
			
			LocalDate dd = convertToLocalDateViaMilisecond(f.getDepartureDate());
			

			if(dd != null) {
			long daysBetween = ChronoUnit.DAYS.between(dd, d);
			if(daysBetween < 14) {
				if(landing.equals(landingCity) && departureC.equals(departureCity)) {
					recomndedF.add(f);
				}
			}
			
			}
			
			
		}
		return recomndedF;
	}
	
	public LocalDate convertToLocalDateViaMilisecond(Date dateToConvert) {
	    java.sql.Date date = new java.sql.Date(dateToConvert.getTime());
	    
	   
	    
	    return date.toLocalDate();
	    
	}
	public boolean updateFlightTicket(String ticketID, boolean isCanclled) {
		ArrayList<FlightTicket>fs = getFlightTickets();

		FlightTicket ticket = new FlightTicket(ticketID);
		if(fs.contains(ticket) == false)
			return false;

		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					CallableStatement stmt = conn.prepareCall(Consts.SQL_UPDATE_FLIGHT_TICKET)) {
				int i = 1;

				stmt.setBoolean(i++, isCanclled);
				stmt.setString(i++, ticketID);

				stmt.executeUpdate();
				return true;

			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return false;
	}
}


