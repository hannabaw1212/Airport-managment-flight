package Control;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Set;

import Boundary.ReportTempClass;
import Entity.Consts;
import Entity.Flight;
import Entity.FlightTicket;

public class ReportControll {
	
	public static ReportControll instance_report = null;
	
	public static ReportControll getInstace() {
		if (instance_report == null)
			instance_report = new ReportControll();
		return instance_report;
	}
	
	public ArrayList<ReportTempClass> generateReport(){
			
		ArrayList<ReportTempClass> results = new ArrayList<ReportTempClass>();
	
		
		
		try {
			
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					PreparedStatement stmt = conn.prepareStatement(Consts.SQL_GET_REPORT);
					ResultSet rs = stmt.executeQuery()) {
				while (rs.next()) {
					int i = 1;
					results.add(new ReportTempClass(rs.getString(i++), rs.getString(i++), rs.getString(i++),
							rs.getString(i++), rs.getString(i++), rs.getString(i++), rs.getString(i++)));
					
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	
		reportHandle(results);
		
		return results;
	}
	
	

	public ArrayList<Flight> getFlights() {
		ArrayList<Flight> results = new ArrayList<Flight>();
		
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					PreparedStatement stmt = conn.prepareStatement(Consts.SQL_GET_FLIGHT);
					ResultSet rs = stmt.executeQuery()) {
				while (rs.next()) {
					int i = 1;
					results.add(new Flight(rs.getString(i++), rs.getString(i++), rs.getString(i++), rs.getDate(i++),
							rs.getInt(i++), rs.getInt(i++), rs.getTime(i++)));



				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return results;
	}
	
	public ArrayList<FlightTicket> getFlightTickets(){
	ArrayList<FlightTicket> results = new ArrayList<FlightTicket>();
		
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					PreparedStatement stmt = conn.prepareStatement(Consts.SQL_GET_FLIGHTTICKETS);
					ResultSet rs = stmt.executeQuery()) {
				while (rs.next()) {
					int i = 1;
					results.add(new FlightTicket(rs.getString(i++), rs.getString(i++), rs.getString(i++), 
							rs.getInt(i++), rs.getString(i++), rs.getInt(i++),
							rs.getString(i++), rs.getString(i++), rs.getBoolean(i++)));
				
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		ArrayList<FlightTicket> can = new ArrayList<>();
		for(int i = 0 ; i < results.size() ; i++) {
			if(results.get(i).getCancelled() == true) {
				can.add(results.get(i));
			}
		}
		results.removeAll(can);
		return results;
	}
	//UPDATEDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD
	private void reportHandle(ArrayList<ReportTempClass> results) {
		// TODO Auto-generated method stub
		ArrayList<FlightTicket> flightTickets = getFlightTickets();
		ArrayList<Flight>jsonF = new ArrayList<>(importControl.getInstace().importJsonFile("json/flights.json").keySet());
		ArrayList<String>jsonFlightsId = new ArrayList<>();
		ArrayList<String> passportNumbers = new ArrayList<>();
		
		for(int i = 0 ; i < flightTickets.size() ; i++) {
			
		}
		for(int i = 0 ; i < jsonF.size() ; i++) {
			jsonFlightsId.add(jsonF.get(i).getFlightID());
		}
		
		for(int i = 0 ; i < flightTickets.size() ; i++) {
			FlightTicket tempT = flightTickets.get(i);
			String flightId = tempT.getFlightId();
			
			if(jsonFlightsId.contains(flightId)) {
				passportNumbers.add(tempT.getPassportNumber());
			}
			
		}
		
		int i = 0;
		int size = results.size();
		ArrayList<ReportTempClass>temp = new ArrayList<>();
		
		while(i < size) {
			if(passportNumbers.contains(results.get(i).getCustomerId()) == false) {
				temp.add(results.get(i));
			}
			i++;
		}
		results.removeAll(temp);
		


	}
}
