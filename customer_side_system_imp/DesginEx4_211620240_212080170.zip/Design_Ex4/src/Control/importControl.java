package Control;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;

import org.json.simple.DeserializationException;
import org.json.simple.JsonArray;
import org.json.simple.JsonObject;
import org.json.simple.Jsoner;

import Entity.Consts;
import Entity.Flight;
import Entity.Seat;

public class importControl {
	private static importControl importControlIns = null;
	private static HashMap<Integer,ArrayList<Seat>> seatsInFlight = new HashMap<>();

	public static importControl getInstace() {
		if (importControlIns == null)
			importControlIns = new importControl();
		return importControlIns;
	}
	//public Flight(String flightID, String landingCity, String departureCity, Date departureDate, int flightTime,
	//int tailNumber, LocalTime departureDateTime) {
	//
	public ArrayList<Flight> getFlights() {
		ArrayList<Flight> results = new ArrayList<Flight>();
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					PreparedStatement stmt = conn.prepareStatement(Consts.SQL_GET_FLIGHT);
					ResultSet rs = stmt.executeQuery()) {
				while (rs.next()) {
					int i = 1;
					results.add(new Flight(rs.getString(i++), rs.getString(i++), rs.getString(i++), rs.getDate(i++),
							rs.getInt(i++), rs.getInt(i++), rs.getTime(i++)));



				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return results;
	}

	public ArrayList<Seat> getSeats(){
		ArrayList<Seat> results = new ArrayList<Seat>();
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					PreparedStatement stmt = conn.prepareStatement(Consts.SQL_GET_SEAT);
					ResultSet rs = stmt.executeQuery()) {
				while (rs.next()) {
					int i = 1;
					results.add(new Seat(rs.getString(i++), rs.getString(i++), rs.getInt(i++),rs.getInt(i++),
							rs.getInt(i++)));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return results;
	}

	public HashMap<Flight,ArrayList<Seat>> importJsonFile(String path){
		HashMap<Flight,ArrayList<Seat>>FlightsAndSeats = new HashMap<>();
		try (FileReader reader = new FileReader(new File(path))){
			JsonObject doc = (JsonObject) Jsoner.deserialize(reader);
			JsonArray flights = (JsonArray) doc.get("flights");
			Iterator<Object> it = flights.iterator();
			while(it.hasNext()) {

				JsonObject obj = (JsonObject) it.next();

				String flightId = (String)obj.get("flightID");
				String landdingCity = (String)obj.get("landingCity");
				String departureCity = (String)obj.get("departureCity");
				String departureDate = (String)obj.get("departureDate");

				LocalDate depDate  = LocalDate.parse(departureDate);
				ZoneId defaultZoneId = ZoneId.systemDefault();
				Date depardate = Date.from(depDate.atStartOfDay(defaultZoneId).toInstant());

				String fT = (String)obj.get("flightTime");

				int flightTime = Integer.parseInt(fT);

				String tn = (String)obj.get("tailNumber");

				int tailNumber = Integer.parseInt(tn);

				String lm = (String) obj.get("departureDateHour");
				LocalTime hour = LocalTime.parse(lm);
				java.sql.Time departureDateHour = java.sql.Time.valueOf(hour);

				String isCanc = (String) obj.get("isCancelled");
				boolean isCanclled = Boolean.parseBoolean(isCanc);

				

				JsonArray arr = (JsonArray) obj.get("seats");
				ArrayList<Seat>seats = new ArrayList<>();
				Iterator<Object> it2 = arr.iterator();
				while(it2.hasNext()) {
					JsonObject obj2 = (JsonObject) it2.next();

					String seatID = (String)obj2.get("SeatID");

					String lineN = (String)obj2.get("lineNumber");
					int lineNumber = Integer.parseInt(lineN);

					String seatLN = (String) obj2.get("seatNumberInLine");
					int seatNumberInLine = Integer.parseInt(seatLN);

					String tailN = (String) obj2.get("tailNumber");
					int tailNum = Integer.parseInt(tailN);

					String seatC = (String) obj2.get("seatClass");

					Seat seat = new Seat(seatID , seatC ,lineNumber, seatNumberInLine, tailNum);
					
					seats.add(seat);

				}
				for(Seat s : seats) {
					if(addSeat(s) == false) {
						updateSeat(s.getSeatID(), s.getSeatClass());
					}
				}
				Flight flight = new Flight(flightId, landdingCity, departureCity, depardate, 
						flightTime, tailNumber, departureDateHour);
				flight.setCancelled(isCanclled);
				
				if(addFlight(flight) == false) {
					updateFlight(flight.getFlightID(), flight.getLandingCity(), flight.getDepartureCity(), flight.getDepartureDate(),
							flight.getFlightTime(), flight.getTailNumber(), flight.getDepartureDateTime(), flight.isCancelled());
				}
				
				
				//public boolean updateFlight(String flightId, String landingCity, String departureCity, Date departureDate,
				//Integer flightTime, Integer tailNumber, java.sql.Time departureDateHour, boolean isCancelled) {
				if(FlightsAndSeats.containsKey(flight) == false) {
					FlightsAndSeats.put(flight, seats);
				}

			}//public Seat(String seatID, String seatClass, int lineNumber, int seatNumberInLine, int tailNumber) {
			//public Flight(String flightID, String landingCity, String departureCity, Date departureDate, int flightTime,
			//int tailNumber, LocalTime departureDateTime) {
			//
			return FlightsAndSeats;

		}catch (IOException | DeserializationException e) {
			e.printStackTrace();
		}
		return FlightsAndSeats;
	}

	public boolean addFlight(Flight flight) {

		String flightID = flight.getFlightID();
		String landingCity = flight.getLandingCity();
		String departureCity = flight.getDepartureCity();
		Date deaprtureDate = flight.getDepartureDate();
		int flighTime = flight.getFlightTime();
		int tailNumber = flight.getTailNumber();
		java.sql.Time departureDateTime = flight.getDepartureDateTime();
		ArrayList<Flight>flights = getFlights();

		if(flights.contains(flight))
			return false;

		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try(Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					CallableStatement stmt = conn.prepareCall(Consts.SQL_ADD_FLIGHT)){
				int i = 1 ;
				stmt.setString(i++, flightID);//cant be null
				stmt.setString(i++, landingCity);
				stmt.setString(i++, departureCity);
				stmt.setDate(i++, new java.sql.Date(deaprtureDate.getTime()));
				stmt.setInt(i++, flighTime);
				stmt.setInt(i++, tailNumber);
				stmt.setTime(i++, departureDateTime);

				stmt.executeUpdate();
				return true;
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		return false;


	}

	public boolean updateFlight(String flightId, String landingCity, String departureCity, Date departureDate,
			Integer flightTime, Integer tailNumber, java.sql.Time departureDateHour, boolean isCancelled) {

		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					CallableStatement stmt = conn.prepareCall(Consts.SQL_UPDATE_FLIGHT)) {
				int i = 1;

				stmt.setString(i++, landingCity); // can't be null
				stmt.setString(i++, departureCity); // can't be null
				if (departureDate != null) {

					stmt.setDate(i++, new java.sql.Date(departureDate.getTime()));
				}
				else
					stmt.setNull(i++, java.sql.Types.VARCHAR);

				if (flightTime != null)
					stmt.setInt(i++, flightTime);
				else
					stmt.setNull(i++, java.sql.Types.INTEGER);

				if (tailNumber != null)
					stmt.setInt(i++, tailNumber);
				else
					stmt.setNull(i++, java.sql.Types.INTEGER);

				if (departureDateHour != null)
					stmt.setTime(i++, departureDateHour);
				else {
					stmt.setNull(i++, java.sql.Types.TIME);
				}

				stmt.setBoolean(i++, isCancelled);

				stmt.setString(i++, flightId);

				stmt.executeUpdate();
				return true;

			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return false;

	}

	public boolean addSeat(Seat seat) {
		ArrayList<Seat>seats = getSeats();

		if(seats.contains(seat)) {
			return false;
		}

		String seatId = seat.getSeatID();
		String seatClass = seat.getSeatClass();
		int lineNumber = seat.getLineNumber();
		int lineNumberInLine = seat.getSeatNumberInLine();
		int tailNumber = seat.getTailNumber();

		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					CallableStatement stmt = conn.prepareCall(Consts.SQL_ADD_SEAT)) {
				int i = 1;

				stmt.setString(i++, seatId);
				stmt.setString(i++, seatClass);
				stmt.setInt(i++, lineNumber);
				stmt.setInt(i++, lineNumberInLine);
				stmt.setInt(i++, tailNumber);

				stmt.executeUpdate();
				return true;

			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return false;


	}
	
	public boolean updateSeat(String seatId, String seatClass) {// only seat class can be changed
			
		ArrayList<Seat>seats = getSeats();
		
		Seat seat = new Seat(seatId);
		if(seats.contains(seat) == false)
			return false;
		
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			try (Connection conn = DriverManager.getConnection(Consts.CONN_STR);
					CallableStatement stmt = conn.prepareCall(Consts.SQL_UPDATE_SEAT)) {
				int i = 1;

				stmt.setString(i++, seatClass);
				stmt.setString(i++, seatId);
				
				stmt.executeUpdate();
				return true;

			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return false;
	}


	//public Seat(String seatID, String seatClass, int lineNumber, int seatNumberInLine, int tailNumber) 
}

