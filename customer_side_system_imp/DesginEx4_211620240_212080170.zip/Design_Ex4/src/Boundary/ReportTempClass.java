package Boundary;

import java.util.Objects;

public class ReportTempClass {
	
	private String customerId;
	private String firstName;
	private String lastName;
	private String morning;
	private String noon;
	private String evening;
	private String night;
	
	
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMorning() {
		return morning;
	}
	public void setMorning(String morning) {
		this.morning = morning;
	}
	public String getNoon() {
		return noon;
	}
	public void setNoon(String noon) {
		this.noon = noon;
	}
	public String getEvening() {
		return evening;
	}
	public void setEvening(String evening) {
		this.evening = evening;
	}
	public String getNight() {
		return night;
	}
	public void setNight(String night) {
		this.night = night;
	}
	public ReportTempClass(String customerId, String firstName, String lastName, String morning, String noon,
			String evening, String night) {
		super();
		this.customerId = customerId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.morning = morning;
		this.noon = noon;
		this.evening = evening;
		this.night = night;
	}
	public ReportTempClass(String customerId) {
		super();
		this.customerId = customerId;
	}
	@Override
	public int hashCode() {
		return Objects.hash(customerId);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ReportTempClass other = (ReportTempClass) obj;
		return Objects.equals(customerId, other.customerId);
	}
	@Override
	public String toString() {
		return "ReportTempClass [customerId=" + customerId + "]";
	}
	
	
	
	
}
