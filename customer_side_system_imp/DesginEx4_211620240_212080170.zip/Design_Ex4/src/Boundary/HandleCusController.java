package Boundary;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Control.HandleCusControl;
import Entity.Customer;
import Entity.Flight;
import Entity.FlightTicket;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

public class HandleCusController implements Initializable{
	
	public static Customer cus = null;
	public static ArrayList<Flight> recFlights;
	public static FlightTicket ticket;
	  @FXML
	    private TextField emailCus;

	    @FXML
	    private ListView<Flight> flightsList;
	    
	    @FXML
	    private Button removeAndSendBtn;

	    @FXML
	    void removeAndSend(ActionEvent event) {
	    	if(ticket.getCancelled() == true) {
				MessageBox.display("Error", "The Ticket Already canclled");
				return;
	    	}
	    	HandleCusControl.getInstace().updateFlightTicket(ticket.getTicketId(), true);
	    	
	    	
	    	MessageBox.display("Done", "Successfully sent email to the customer with the updates and successfully canclled the ticket");
	    	
	    }

		@Override
		public void initialize(URL location, ResourceBundle resources) {
			// TODO Auto-generated method stub
			emailCus.setText(cus.getEmail());
			System.out.println(ticket);
			System.out.println(HandleCusControl.getInstace().recomndedFlight(ticket));
			fillListView();
			
			
		}

		private void fillListView() {
			// TODO Auto-generated method stub
			
			ObservableList<Flight> cd=FXCollections.observableArrayList();
	    	for(Flight d : HandleCusControl.getInstace().recomndedFlight(ticket)) {
	    		cd.add(d);
	    	}
	    	flightsList.setItems(cd);
		}
	    
	    
	    
	    
}
