package Boundary;

import java.util.ArrayList;

import Entity.Customer;
import Entity.Flight;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;

public class HomePageCotroller {
		
	public static ArrayList<Customer>customerRep = new ArrayList<>();
	public static ArrayList<Flight>flightsJson = new ArrayList<>();

    @FXML
    private Button jsonPage;

    @FXML
    private Button removePage;

    @FXML
    private Button reportPage;

    @FXML
    private Button uapdeBtn;

    @FXML
    void goToJson(ActionEvent event) {
    	try {
			Parent root = FXMLLoader.load(getClass().getResource("JsonScene.fxml"));
			Scene scene = new Scene(root);
			RunnerClass.mainS.setScene(scene);

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
    }

    @FXML
    void goToRemove(ActionEvent event) {

    }

    @FXML
    void goToReport(ActionEvent event) {
    	try {
			Parent root = FXMLLoader.load(getClass().getResource("ReportScene.fxml"));
			Scene scene = new Scene(root);
			RunnerClass.mainS.setScene(scene);

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
    }

    @FXML
    void goToUpdate(ActionEvent event) {

    }
}
