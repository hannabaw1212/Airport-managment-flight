package Boundary;
import java.util.ArrayList;

import Control.ReportControll;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class ReportController {
	
	  @FXML
	    private Button generateReportBtn;

	    @FXML
	    private Button homeBtn;

	    @FXML
	    void generateReportFunc(ActionEvent event) {
	    	
	    	Stage st= new Stage();
			try {
				Parent root = FXMLLoader.load(getClass().getResource("GeneratedReportScene.fxml"));
				Scene scene = new Scene(root);
				st.setScene(scene);
				st.setResizable(false);
				st.showAndWait();
			} catch (Exception e) {
				e.printStackTrace();
			}

	    	
	    	
	    }

	    @FXML
	    void goHome(ActionEvent event) {
	    	try {
				Parent root = FXMLLoader.load(getClass().getResource("HomePage.fxml"));
				Scene scene = new Scene(root);
				RunnerClass.mainS.setScene(scene);

			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
	    }
}
