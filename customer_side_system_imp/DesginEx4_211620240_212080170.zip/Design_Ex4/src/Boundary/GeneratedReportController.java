package Boundary;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Control.HandleCusControl;
import Control.ReportControll;
import Entity.Customer;
import Entity.Flight;
import Entity.FlightTicket;
import Entity.Seat;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;


public class GeneratedReportController implements Initializable{
	
	  @FXML
	    private Button Home;

	    @FXML
	    private TableColumn<ReportTempClass, String> customerIdCln;

	    @FXML
	    private TableColumn<ReportTempClass, String> eveningCln;

	    @FXML
	    private TableColumn<ReportTempClass, String> fNameCln;

	    @FXML
	    private TableColumn<ReportTempClass, String> lNameCLn;

	    @FXML
	    private TableColumn<ReportTempClass, String> morningCln;

	    @FXML
	    private TableColumn<ReportTempClass, String> nightCln;

	    @FXML
	    private TableColumn<ReportTempClass, String> noonCln;
	    
	    @FXML
	    private TableView<ReportTempClass> reportTable;
	    
	    @FXML
	    private Button contactBtn;

		@Override
		public void initialize(URL location, ResourceBundle resources) {
			// TODO Auto-generated method stub
			fillTableView();
			
		}

		public void fillTableView() {
			// TODO Auto-generated method stub
			ObservableList<ReportTempClass>data;
	    	data=FXCollections.observableArrayList();
	    	
	    	for(ReportTempClass c: ReportControll.getInstace().generateReport()) {
	    		
	    		data.add(c);
		}
	    	
	    	customerIdCln.setCellValueFactory(new PropertyValueFactory<>("customerId"));
	    	fNameCln.setCellValueFactory(new PropertyValueFactory<>("firstName"));
	    	lNameCLn.setCellValueFactory(new PropertyValueFactory<>("lastName"));
	    	morningCln.setCellValueFactory(new PropertyValueFactory<>("morning"));
	    	noonCln.setCellValueFactory(new PropertyValueFactory<>("noon"));
	    	eveningCln.setCellValueFactory(new PropertyValueFactory<>("evening"));
	    	nightCln.setCellValueFactory(new PropertyValueFactory<>("night"));
	    	
	    	
	    	reportTable.setItems(data);
			
		}
	    
		@FXML
	    void contactCus(ActionEvent event) {
			if(reportTable.getSelectionModel().getSelectedIndex() == -1) {
				MessageBox.display("Error", "Please choose a customer from the table to contact with");
				return;
			}
			ReportTempClass temp= reportTable.getSelectionModel().getSelectedItem();
			
			Stage window = new Stage();
			
			//open a new small widonw
			window.initModality(Modality.APPLICATION_MODAL);
			window.setTitle("Customer flightTickets");
			window.setMinWidth(300);
			window.setMinHeight(300);
			window.setHeight(600);
			window.setWidth(500);
			
			String customerId = reportTable.getSelectionModel().getSelectedItem().getCustomerId();
			
			Customer customer = HandleCusControl.getInstace().getCustomerById(customerId);
			ArrayList<FlightTicket> flighTic = HandleCusControl.getInstace().getFlightTicketByCusId(customer);
			
			ObservableList<FlightTicket> cd3=FXCollections.observableArrayList(flighTic);
			
			ListView<FlightTicket>seatInF = new ListView<>();
			
			seatInF.setItems(cd3);
			
			Button updateCus = new Button("choose ticket to delete and go contact  with customer");

			updateCus.setOnAction(new EventHandler<ActionEvent>() {//action that when we type the button we do this

			@Override
			public void handle(ActionEvent event) {
					
				if(seatInF.getSelectionModel().getSelectedIndex() == -1) {
					MessageBox.display("Error", "Please choose a flight ticket");
					return;
				}
				
				FlightTicket temp = seatInF.getSelectionModel().getSelectedItem();
				
				HandleCusController.ticket = temp;
				HandleCusController.cus = customer;
				
				Stage st= new Stage();
				try {
					Parent root = FXMLLoader.load(getClass().getResource("UpdateCusScene.fxml"));
					Scene scene = new Scene(root);
					st.setScene(scene);
					st.setResizable(false);
					st.showAndWait();
				} catch (Exception e) {
					e.printStackTrace();
				}
				
			}
			
	    });
			VBox layout = new VBox();
			layout.getChildren().addAll(seatInF, updateCus);
			layout.setAlignment(Pos.CENTER);
			Scene scene = new Scene(layout);
			window.setScene(scene);
			window.showAndWait();
		

}
		
}
