package Boundary;
import java.net.URL;
import java.sql.Date;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.ResourceBundle;

import Control.importControl;
import Entity.Flight;
import Entity.Seat;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class JsonAndReportSceneCotroller implements Initializable{
	static HashMap<Flight,ArrayList<Seat>> seatInFlight;
	 @FXML
	    private Button homeBtn;

	    @FXML
	    private Button jsonBtn;

	    @FXML
	    private ListView<Flight> managerFlyData;

	    
	    
	    @FXML
	    private Button seatsBtn;
	    
	    
	    @FXML
	    void showFlightSeats(ActionEvent event) {
	    	
	    	
	    	if(managerFlyData.getItems().size() == 0) {
	    		MessageBox.display("error", "import the json first");
	        	return;
		
	    	}
	    	if(managerFlyData.getSelectionModel().getSelectedIndex()==-1)//to make sure that the user choosed component from the table
	    	{
	        	MessageBox.display("error", "Please choose a flight from the list");
	        	return;
		
	    	}
	    	
	    	Stage window = new Stage();
			
			//open a new small widonw
			window.initModality(Modality.APPLICATION_MODAL);
			window.setTitle("seats in flight");
			window.setMinWidth(300);
			window.setMinHeight(300);
			window.setHeight(600);
			window.setWidth(500);
	    	
	    	ObservableList<Seat> cd3=FXCollections.observableArrayList(seatInFlight.get(managerFlyData.getSelectionModel().getSelectedItem()));
	    	ListView<Seat>seatInF = new ListView<>();
	    	seatInF.setItems(cd3);
	    	
	    	VBox layout = new VBox(1);
	    	layout.getChildren().add(seatInF);
	    	layout.setAlignment(Pos.CENTER);
			Scene scene = new Scene(layout);
			window.setScene(scene);
			window.showAndWait();
	    	
	    }

	  

	    @FXML
	    void goHome(ActionEvent event) {
	    	try {
				Parent root = FXMLLoader.load(getClass().getResource("HomePage.fxml"));
				Scene scene = new Scene(root);
				RunnerClass.mainS.setScene(scene);

			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
	    }

	    @FXML
	    void importJson(ActionEvent event) {
	    	
	    	fillListView();
	    	
	    }

	    public void fillListView() {
	    	HashMap<Flight,ArrayList<Seat>> imported= importControl.getInstace().importJsonFile("json/flights.json");
	    	ArrayList<Flight> list = new ArrayList<>(imported.keySet());
	    	ObservableList<Flight> cd=FXCollections.observableArrayList();
	    	cd.addAll(list);
	    	managerFlyData.setItems(cd);
	    	seatInFlight = new HashMap<>(imported);
	    	
	    }
		@Override
		public void initialize(URL location, ResourceBundle resources) {
			// TODO Auto-generated method stub
//			System.out.println(importControl.getInstace().getFlights());
			LocalDate d1 = LocalDate.of(2021, 12, 28);
			LocalDate d2  = LocalDate.of(2022, 1, 4);
			System.out.println( ChronoUnit.DAYS.between(d1, d2));
		}
	
}
